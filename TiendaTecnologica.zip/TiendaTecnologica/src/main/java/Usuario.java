/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Amalia
 */
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import java.util.Map;

class Usuario {
    private int id;
    private String nombre;
    private String email;
    private Direccion direccion;
    private List<HistorialCompra> historialCompras;

    // Getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Direccion getDireccion() {
        return direccion;
    }

    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }

    public List<HistorialCompra> getHistorialCompras() {
        return historialCompras;
    }

    public void setHistorialCompras(List<HistorialCompra> historialCompras) {
        this.historialCompras = historialCompras;
    }
}
